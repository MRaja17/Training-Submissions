# hard2/app.py — tiny CLI for common SQL tasks
import sqlite3, argparse, pandas as pd

def run(sql, db="mini.sqlite"):
    con = sqlite3.connect(db)
    df = pd.read_sql_query(sql, con)
    con.close()
    return df

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default="mini.sqlite")
    ap.add_argument("--task", choices=["revenue_by_city_month","top_customers","top_products"], required=True)
    args = ap.parse_args()

    if args.task == "revenue_by_city_month":
        sql = open("queries.sql","r",encoding="utf-8").read().split(";")[0]
    elif args.task == "top_customers":
        sql = open("queries.sql","r",encoding="utf-8").read().split(";")[1]
    else:
        sql = open("queries.sql","r",encoding="utf-8").read().split(";")[2]

    df = run(sql, db=args.db)
    print(df.to_string(index=False))