# hard2/load_data.py — generate synthetic e-commerce data
import sqlite3, random, string
from datetime import date, timedelta

def rand_sku():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))

def rand_date(start=date(2024,1,1), end=date(2025,11,1)):
    delta = end - start
    d = start + timedelta(days=random.randint(0, delta.days))
    return d.isoformat()

def main(db_path="mini.sqlite"):
    con = sqlite3.connect(db_path)
    cur = con.cursor()
    with open("schema.sql","r",encoding="utf-8") as f:
        cur.executescript(f.read())

    cities = ["Dallas","Austin","Houston","San Antonio","El Paso","Fort Worth","Plano","Irving"]
    statuses = ["NEW","PAID","SHIPPED","CANCELLED","REFUNDED"]

    # Customers
    customers = []
    for i in range(1, 3001):
        customers.append((i, f"Customer {i}", f"user{i}@example.com", random.choice(cities)))
    cur.executemany("INSERT INTO customers(customer_id,name,email,city) VALUES(?,?,?,?)", customers)

    # Products
    products = []
    for i in range(1, 201):
        sku = rand_sku()
        products.append((i, sku, f"Product {i}", round(random.uniform(5, 200), 2)))
    cur.executemany("INSERT INTO products(product_id,sku,name,price) VALUES(?,?,?,?)", products)

    # Orders + Items
    oid = 1
    itid = 1
    for _ in range(20000):
        cid = random.randint(1, 3000)
        od = rand_date()
        st = random.choices(statuses, weights=[3,5,4,1,1])[0]
        cur.execute("INSERT INTO orders(order_id,customer_id,order_date,status) VALUES(?,?,?,?)",
                    (oid, cid, od, st))
        for _ in range(random.randint(1,4)):
            pid = random.randint(1,200)
            qty = random.randint(1,5)
            price = cur.execute("SELECT price FROM products WHERE product_id=?", (pid,)).fetchone()[0]
            cur.execute("INSERT INTO order_items(order_item_id,order_id,product_id,qty,unit_price) VALUES(?,?,?,?,?)",
                        (itid, oid, pid, qty, price))
            itid += 1
        oid += 1

    con.commit()
    con.close()
    print("Generated mini.sqlite with synthetic data.")

if __name__ == "__main__":
    main()