-- hard2/queries.sql — a pack of typical analytics queries

-- Revenue by city and month
WITH line AS (
  SELECT o.order_id, c.city, substr(o.order_date,1,7) AS ym,
         (oi.qty * oi.unit_price) AS line_total, o.status
  FROM orders o
  JOIN customers c ON c.customer_id = o.customer_id
  JOIN order_items oi ON oi.order_id = o.order_id
)
SELECT city, ym, ROUND(SUM(line_total), 2) AS revenue
FROM line
WHERE status IN ('PAID','SHIPPED')
GROUP BY city, ym
ORDER BY city, ym;

-- Top 10 customers by lifetime value
WITH line AS (
  SELECT o.customer_id, (oi.qty * oi.unit_price) AS line_total, o.status
  FROM orders o
  JOIN order_items oi ON oi.order_id = o.order_id
)
SELECT c.customer_id, c.name, ROUND(SUM(line_total), 2) AS ltv
FROM line
JOIN customers c USING(customer_id)
WHERE status IN ('PAID','SHIPPED')
GROUP BY c.customer_id, c.name
ORDER BY ltv DESC
LIMIT 10;

-- Product velocity: units sold per product
WITH paid AS (
  SELECT oi.product_id, SUM(oi.qty) AS units
  FROM orders o
  JOIN order_items oi ON oi.order_id = o.order_id
  WHERE o.status IN ('PAID','SHIPPED')
  GROUP BY oi.product_id
)
SELECT p.product_id, p.sku, p.name, COALESCE(units,0) AS units_sold
FROM products p
LEFT JOIN paid USING(product_id)
ORDER BY units_sold DESC, product_id
LIMIT 20;