-- Easy 2 — Toy example
-- Two tiny tables: students and enrollments, joined to list who is in which course.

-- Schema
CREATE TABLE students (student_id INTEGER PRIMARY KEY, name TEXT);
CREATE TABLE enrollments (enrollment_id INTEGER PRIMARY KEY, student_id INTEGER, course TEXT);

-- Seed
INSERT INTO students (student_id, name) VALUES
  (1, 'Asha'),
  (2, 'Ben'),
  (3, 'Chao');

INSERT INTO enrollments (enrollment_id, student_id, course) VALUES
  (11, 1, 'SQL 101'),
  (12, 2, 'SQL 101'),
  (13, 2, 'Python 101');

-- Query: Who is enrolled in SQL 101? (name + course), ordered by name
SELECT s.name, e.course
FROM enrollments e
JOIN students s ON s.student_id = e.student_id
WHERE e.course = 'SQL 101'
ORDER BY s.name;