"""
Intermediate 2 — Implement SQL Basics using Python's built-in sqlite3.
Run: python intermediate2_sqlite.py
"""
import sqlite3, pandas as pd

def run_queries(db_path: str):
    con = sqlite3.connect(db_path)
    qlist = {
  "Top 5 most fuel efficient cars": "\n        SELECT model, mpg\n        FROM mtcars\n        ORDER BY mpg DESC\n        LIMIT 5;\n    ",
  "Average MPG by cylinder count (group + having)": "\n        SELECT cyl, ROUND(AVG(mpg), 2) AS avg_mpg, COUNT(*) AS n\n        FROM mtcars\n        GROUP BY cyl\n        HAVING COUNT(*) >= 3\n        ORDER BY cyl;\n    ",
  "Lightweight performance (filter + order)": "\n        SELECT model, mpg, hp, wt\n        FROM mtcars\n        WHERE wt < 2.5 AND hp > 100\n        ORDER BY hp DESC;\n    ",
  "Manual vs automatic \u2014 median horsepower (window approx)": "\n        WITH hp_sorted AS (\n          SELECT am, hp,\n                 ROW_NUMBER() OVER (PARTITION BY am ORDER BY hp) AS rn,\n                 COUNT(*)    OVER (PARTITION BY am) AS total\n          FROM mtcars\n        )\n        SELECT am,\n               AVG(hp) AS approx_median_hp\n        FROM hp_sorted\n        WHERE rn IN (total/2, total/2 + 1) OR rn = (total + 1)/2\n        GROUP BY am\n        ORDER BY am;\n    ",
  "Which 3-cylinder groups (gear, carb) have avg mpg > 25? (join style group)": "\n        SELECT gear, carb, ROUND(AVG(mpg),2) AS avg_mpg, COUNT(*) AS n\n        FROM mtcars\n        GROUP BY gear, carb\n        HAVING AVG(mpg) > 25\n        ORDER BY avg_mpg DESC, n DESC;\n    "
}
    out = {}
    for title, q in qlist.items():
        cur = con.execute(q)
        cols = [d[0] for d in cur.description]
        rows = cur.fetchall()
        out[title] = (cols, rows)
    con.close()
    return out

if __name__ == "__main__":
    db_path = "intermediate1.sqlite"
    out = run_queries(db_path)
    for title, (cols, rows) in out.items():
        print("\n===", title, "===")
        print(pd.DataFrame(rows, columns=cols).to_string(index=False))