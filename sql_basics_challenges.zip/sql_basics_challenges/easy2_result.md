# Easy 2 — Result

| name   | course   |
|:-------|:---------|
| Asha   | SQL 101  |
| Ben    | SQL 101  |