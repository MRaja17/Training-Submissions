# Intermediate 1 — SQL on a real dataset (*mtcars*)

## Top 5 most fuel efficient cars

| model          |   mpg |
|:---------------|------:|
| Toyota Corolla |  33.9 |
| Fiat 128       |  32.4 |
| Honda Civic    |  30.4 |
| Lotus Europa   |  30.4 |
| Fiat X1-9      |  27.3 |


## Average MPG by cylinder count (group + having)

|   cyl |   avg_mpg |   n |
|------:|----------:|----:|
|     4 |     26.66 |  11 |
|     6 |     19.74 |   7 |
|     8 |     15.1  |  14 |


## Lightweight performance (filter + order)

| model        |   mpg |   hp |    wt |
|:-------------|------:|-----:|------:|
| Lotus Europa |  30.4 |  113 | 1.513 |


## Manual vs automatic — median horsepower (window approx)

|   am |   approx_median_hp |
|-----:|-------------------:|
|    0 |              162.5 |
|    1 |              101   |


## Which 3-cylinder groups (gear, carb) have avg mpg > 25? (join style group)

|   gear |   carb |   avg_mpg |   n |
|-------:|-------:|----------:|----:|
|      4 |      1 |      29.1 |   4 |
|      5 |      2 |      28.2 |   2 |

