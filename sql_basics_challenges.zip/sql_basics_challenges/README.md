# SQL Basics — Weekly Challenges

This repo folder contains completed deliverables for:
- Easy 1, Easy 2
- Intermediate 1, Intermediate 2
- Hard 1, Hard 2 (mini project)

## Quick Start

```bash
# (from this folder)
# Toy example
sqlite3 easy2_toy.sqlite < easy2_toy.sql
sqlite3 easy2_toy.sqlite "SELECT * FROM enrollments;"

# Real dataset demo
sqlite3 intermediate1.sqlite "SELECT COUNT(*) FROM mtcars;"
python intermediate2_sqlite.py

# Performance demo
sqlite3 hard1_perf.sqlite "SELECT COUNT(*) FROM orders;"

# Mini project
cd hard2_mini_project
python load_data.py             # builds mini.sqlite
python app.py --task top_customers
python app.py --task top_products
python app.py --task revenue_by_city_month
```

## Files

- `easy1_concepts.md` — conceptual writeup
- `easy2_toy.sql` & `easy2_toy.sqlite` — toy DB and query. Output in `easy2_result.md`
- `intermediate1_mtcars.csv` + `intermediate1.sqlite` + `intermediate1_report.md`
- `intermediate2_sqlite.py` — programmatic SQL
- `hard1_perf.sqlite` + `hard1_optimization.md`
- `hard2_mini_project/` — end-to-end mini project (schema, loader, queries, CLI)

> All datasets here are local and reproducible, so no external downloads are required.