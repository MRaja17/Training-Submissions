# Hard 1 — Performance optimization

**Workload:** Compute total revenue by city and year for PAID/SHIPPED orders in 2024–2025.

**Baseline (no indexes) avg time:** 0.072791 seconds  
**With indexes** avg time: 0.102085 seconds  
**Results identical?** True

**Indexes used**
- `orders(status, order_date)` helps the selective filter by status and date range.
- `orders(customer_id)` accelerates the join to `customers`.
- `customers(city)` makes grouping and ordering by city cheaper.

**Query**
```sql
SELECT c.city, substr(o.order_date,1,4) AS yyyy, ROUND(SUM(o.amount),2) AS revenue
FROM orders o
JOIN customers c ON c.customer_id = o.customer_id
WHERE o.status IN ('PAID','SHIPPED')
  AND o.order_date >= '2024-01-01' AND o.order_date < '2026-01-01'
GROUP BY c.city, yyyy
ORDER BY revenue DESC;
```

**Top of result preview**

| city        |   yyyy |   revenue |
|:------------|-------:|----------:|
| Fort Worth  |   2025 |    370403 |
| Plano       |   2025 |    367384 |
| Austin      |   2025 |    359679 |
| Austin      |   2024 |    359362 |
| El Paso     |   2025 |    355545 |
| Fort Worth  |   2024 |    355345 |
| Plano       |   2024 |    353171 |
| El Paso     |   2024 |    352598 |
| San Antonio |   2024 |    348599 |
| Irving      |   2024 |    346914 |